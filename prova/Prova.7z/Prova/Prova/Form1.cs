﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Prova
{
    public partial class frmVendas : Form
    {
        double[,] valores = new double[4,4];
        double totalMes = 0, totalGeral = 0, valor;

        public frmVendas()
        {
            InitializeComponent();
        }

        private void frmEnviar_Click(object sender, EventArgs e)
        {
            for (int mes = 0; mes < 4; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    string valor = Interaction.InputBox("Insira um valor:", "Insira os valores");
                    if (!double.TryParse(valor, out valores[mes, semana]))
                        MessageBox.Show("Digite um valor válido");
                    if (mes == 0 && semana == 0) { 
                        lbxTotal.Items.Add("Total do mês 1 - semana 1:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 0 && semana == 1)
                    {
                        lbxTotal.Items.Add("Total do mês 1 - semana 2:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 0 && semana == 2)
                    {
                        lbxTotal.Items.Add("Total do mês 1 - semana 3:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 0 && semana == 3)
                    {
                        lbxTotal.Items.Add("Total do mês 1 - semana 4:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                        lbxTotal.Items.Add("Total mês: ");
                        lbxTotal.Items.Add(totalMes.ToString());
                        lbxTotal.Items.Add("\n");
                        totalGeral += totalMes;
                    }

                    

                    if (mes == 1 && semana == 0)
                    {
                        totalMes = 0;
                        lbxTotal.Items.Add("Total do mês 2 - semana 1:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 1 && semana == 1)
                    {
                        lbxTotal.Items.Add("Total do mês 2 - semana 2:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 1 && semana == 2)
                    {
                        lbxTotal.Items.Add("Total do mês 2 - semana 3:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 1 && semana == 3)
                    {
                        lbxTotal.Items.Add("Total do mês 2 - semana 4:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                        lbxTotal.Items.Add("Total mês: ");
                        lbxTotal.Items.Add(totalMes.ToString());
                        lbxTotal.Items.Add("\n");
                        totalGeral += totalMes;
                    }


                    if (mes == 2 && semana == 0)
                    {
                        totalMes = 0;
                        lbxTotal.Items.Add("Total do mês 3 - semana 1:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 2 && semana == 1)
                    {
                        lbxTotal.Items.Add("Total do mês 3 - semana 2:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 2 && semana == 2)
                    {
                        lbxTotal.Items.Add("Total do mês 3 - semana 3:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 2 && semana == 3)
                    {
                        lbxTotal.Items.Add("Total do mês 3 - semana 4:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                        lbxTotal.Items.Add("Total mês: ");
                        lbxTotal.Items.Add(totalMes.ToString());
                        lbxTotal.Items.Add("\n");
                        totalGeral += totalMes;
                    }



                    if (mes == 3 && semana == 0)
                    {
                        totalMes = 0;
                        lbxTotal.Items.Add("Total do mês 4 - semana 1:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 3 && semana == 1)
                    {
                        lbxTotal.Items.Add("Total do mês 4 - semana 2:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 3 && semana == 2)
                    {
                        lbxTotal.Items.Add("Total do mês 4 - semana 3:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                    }
                    else if (mes == 3 && semana == 3)
                    {
                        lbxTotal.Items.Add("Total do mês 4 - semana 4:");
                        lbxTotal.Items.Add(valor.ToString());
                        totalMes += Double.Parse(valor);
                        lbxTotal.Items.Add("Total mês: ");
                        lbxTotal.Items.Add(totalMes.ToString());
                        lbxTotal.Items.Add("\n");
                        totalGeral += totalMes;
                    }
                }
            }

            lbxTotal.Items.Add("Total Geral: ");
            lbxTotal.Items.Add(totalGeral);
            
        }
    }
}
